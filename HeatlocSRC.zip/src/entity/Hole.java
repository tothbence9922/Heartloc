package entity;

public class Hole extends Entity {

	public Hole(String id) {
		super(id);
	}

	@Override
	public int step() {
		// TODO
		return 0;
	}

}
