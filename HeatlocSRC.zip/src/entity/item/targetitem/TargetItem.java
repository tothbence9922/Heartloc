package entity.item.targetitem;

import entity.item.Item;

public abstract class TargetItem extends Item {

	public TargetItem(String id) {
		super(id);
	}	
}
