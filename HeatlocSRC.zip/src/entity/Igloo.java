package entity;

public class Igloo extends Building {

	public Igloo(String id) {
		super(id);
	}

	@Override
	public int step() {
		// TODO
		return 0;
	}

}
