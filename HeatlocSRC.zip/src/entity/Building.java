package entity;

public class Building extends Entity {
	
	@Override
	public int step() {
		// TODO
		return 0;
	}
	
	public Building(String id) {super(id);}
	
}
