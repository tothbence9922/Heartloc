package entity;

public class Snow extends Entity {

	public Snow(String id) {
		super(id);
		// TODO
	}

	@Override
	public int step() {
		// TODO
		return 0;
	}

}