package entity;

public class Tent extends Building  {

	public Tent(String id) {
		super(id);
	}
	
}
