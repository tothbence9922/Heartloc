package model;

import java.util.Scanner;

import org.json.simple.parser.ParseException;

public class Main extends Commands {

	public static void main(String[] args) throws ParseException {

		Scanner s = new Scanner(System.in);
		while (true) {
			String input = s.nextLine();
			String[] tokens = input.split(" ");

			if (tokens[0].equals("loadMap")) {
				loadMap(tokens);
			} else if (tokens[0].equals("addSnow")) {
				addSnow(tokens);
			} else if (tokens[0].equals("addShovel")) {
				addShovel(tokens);
			} else if (tokens[0].equals("addRope")) {
				addRope(tokens);
			} else if (tokens[0].equals("addPolarBear")) {
				addPolarBear(tokens);
			} else if (tokens[0].equals("addIgloo")) {
				addIgloo(tokens);
			} else if (tokens[0].equals("addHole")) {
				addHole(tokens);
			} else if (tokens[0].equals("addTent")) {
				addTent(tokens);
			} else if (tokens[0].equals("addFragileShovel")) {
				addFragileShovel(tokens);
			} else if (tokens[0].equals("addFood")) {
				addFood(tokens);
			} else if (tokens[0].equals("addExplorer")) {
				addExplorer(tokens);
			} else if (tokens[0].equals("addEskimo")) {
				addEskimo(tokens);
			} else if (tokens[0].equals("addCartridge")) {
				addCartridge(tokens);
			} else if (tokens[0].equals("addGun")) {
				addGun(tokens);
			} else if (tokens[0].equals("addBeacon")) {
				addBeacon(tokens);
			}else if (tokens[0].equals("giveCartridge")) {
				giveCartridge(tokens);
			} else if (tokens[0].equals("giveGun")) {
				giveGun(tokens);
			} else if (tokens[0].equals("giveBeacon")) {
				giveBeacon(tokens);
			} else if (tokens[0].equals("giveRocket")) {
				giveRocket(tokens);
			} else if (tokens[0].equals("giveFood")) {
				giveFood(tokens);
			} else if (tokens[0].equals("giveFragileShovel")) {
				giveFragileShovel(tokens);
			} else if (tokens[0].equals("giveShovel")) {
				giveShovel(tokens);
			} else if (tokens[0].equals("giveRope")) {
				giveRope(tokens);
			} else if (tokens[0].equals("giveTent")) {
				giveTent(tokens);
			} else if (tokens[0].equals("giveWetsuit")) {
				giveWetsuit(tokens);
			} else if (tokens[0].equals("exploreTile")) {
				exploreTile(tokens);
			} else if (tokens[0].equals("move")) {
				move(tokens);
			} else if (tokens[0].equals("createStorm")) {
				createStorm(tokens);
			} else if (tokens[0].equals("dig")) {
				dig(tokens);
			} else if (tokens[0].equals("buildIgloo")) {
				buildIgloo(tokens);
			} else if (tokens[0].equals("damage")) {
				damage(tokens);
			} else if (tokens[0].equals("useFood")) {
				useFood(tokens);
			}else if (tokens[0].equals("useBeacon")) {
				useBeacon(tokens);
			} else if (tokens[0].equals("useCartridge")) {
				useCartridge(tokens);
			} else if (tokens[0].equals("useGun")) {
				useGun(tokens);
			} else if (tokens[0].equals("useRocket")) {
				useRocket(tokens);
			} else if(tokens[0].equals("buildTent")) {
				buildTent(tokens);
			} else if(tokens[0].contentEquals("exit")) {
				break;
			}

		}
		s.close();

		/*
		 * try { MapLoader.readMapFromJSON("./assets/maps/temp.json");
		 * 
		 * System.out.println((Game.getInstance()).toString());
		 * 
		 * Game.getInstance(); Game.getPlayers().get(0).addToInventory(new
		 * FragileShovel("Fra2")); Game.getPlayers().get(0).addToInventory(new
		 * FragileShovel("Fra3")); Game.getPlayers().get(0).addToInventory(new
		 * FragileShovel("Fra4"));
		 * 
		 * //Game.getPlayers().get(0).damage(3);
		 * System.out.println(Game.getPlayers().get(0).exploreTile(new
		 * StableTile("t1"))); Game.getPlayers().get(0).heal(2);
		 * 
		 * System.out.println((Game.getInstance()).toString());
		 * //System.out.println((Game.getInstance()).toJSON());
		 * 
		 * FileWriter fw = new FileWriter("./assets/maps/temp.json");
		 * fw.write(Game.getInstance().toJSON()); fw.close(); } catch (Exception e){
		 * e.printStackTrace();}
		 */

	}
}
