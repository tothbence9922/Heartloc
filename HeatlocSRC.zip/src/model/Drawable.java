package model;

public interface Drawable {
	public void draw();
}
